public class Value {
	public static int groundGrass = 0;
	public static int groundRoad = 1;

	public static int airAir = -1;
	public static int airCave = 0;
	public static int airTrashCan = 1;
	public static int airTowerLaser = 2;

	public static int mobAir = -1;
	public static int mobGreen = 0;

	public static int[] deathReward = { 2 };
}
